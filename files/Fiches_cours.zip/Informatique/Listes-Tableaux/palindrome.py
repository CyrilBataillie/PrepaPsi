﻿# Créé par teuvrard, le 05/11/2014 en Python 3.2

def palindrome(texte):
    if type(texte)!=str:
        return 'Vous devez donner une chaine de caractère'
    nvtexte=''
    n=len(texte)
    for i in range (0,n):
        nvtexte=nvtexte+texte[n-i-1]
    if texte==nvtexte:
        return texte+' est un palindrome'
    else:
        return texte+' n\'est pas un palindrome'

def palindrome1(texte):
    if type(texte)!=str:
        return 'Vous devez donner une chaine de caractère'
    n=len(texte)
    for i in range (0,n//2):
        if texte[i]!=texte[n-i-1]:
            return texte+' n\'est pas un palindrome'
        else:
            return texte+' est un palindrome'