﻿# Créé par oriviere, le 08/10/2014 en Python 3.2
def listealea():
    import random
    n=int(input('donne la taille de la liste à trier'))
    Ltest=[]
    for j in range(n):
        Ltest.append(random.randint(-5*n,5*n))
    return Ltest




def tribulles(L):
    n=len(L)
    for k in range(n):
        for i in range(n-k-1):
            if L[i]>L[i+1]:
                L[i],L[i+1]=L[i+1],L[i]
    return(L)


L=listealea()
print(tribulles(L))



def triinsertion(L):
    n=len(L)
    for i in range(1,n):
        x=L[i]
        j=1
        while i-j>=0 and x<L[i-j]:                     #on compare toujours le i-eme element au i-1 eme element.
            L[i-j+1]=L[i-j]                            #On le ramene dune position en arriere tant qu il est inferieur.
            j=j+1
        L[i-j+1]=x
    return(L)



print(triinsertion(L))




def trirapide(L):
    n=len(L)
    Lmax=[]
    Lmin=[]
    if n<2:
        return(L)
    x=L[n-1]
    for i in range(n-1):
        if L[i]<=x:
            Lmin.append(L[i])
        else:
            Lmax.append(L[i])
    return trirapide(Lmin)+[x]+trirapide(Lmax)

print(trirapide(L))




def fusion(L1,L2):
    LF=[]
    while len(L1)!=0 and len(L2)!=0:
        if L1[0]>L2[0]:
            LF.append(L1[0])
            L1.pop(0)
        else:
            LF.append(L2[0])
            L2.pop(0)
    if len(L1)==0:
        LF.extend(L2)
        return(LF)
    if len(L2)==0:
        LF.extend(L1)
        return(LF)



def trifusion(L):
    if len(L)<2:
        return L
    L1=L[0:len(L)//2]
    L2=L[len(L)//2+1:len(L)-1]



print(trifusion(L))























































