﻿"""Méthodes pour résoudre f(x)=0"""

from maths import *


def dichotomie(f,a,b,epsilon):
    if f(a)*f(b)>0:
        return "Erreur ! La fonction ne s'annule pas sur [a,b]."
    elif f(a)==0:
        return a
    elif f(b)==0:
        return b

    if f(a)>0:
        An=b
        Bn=a
    else:
        An=a
        Bn=b

    while Bn-An<2*epsilon:
        c=(An+Bn)/2
        if f(c)==0:
            return c
        elif f(c)<0:
            An=c
        elif f(c)>0:
            Bn=c

    return c






def Newton(f,g,a,b,epsilon):
    if f(a)*(g(a+(b-a)/100)-g(a))/((a+(b-a)/100)-a)>0:
        Un=a
    else:
        Un=b

    Un1=Un-f(Un)/g(Un)


    while abs(Un1-Un)<epsilon:
        Un=Un1
        Un1=Un-f(Un)/g(Un)

    return Un1






def FaussePosition(f,a,b,epsilon):
    Vn=(((f(b)-f(a))/b-a)-f(a))/((f(b)-f(a))/b-a)
    Mn=f(Vn)

    if f(a)*f(Vn)<0:
        Vn1=(((f(Vn)-f(a))/Vn-a)-f(a))/((f(Vn)-f(a))/Vn-a)
        while abs(Vn1-Vn)<epsilon:
            Vn=Vn1
            Vn1=(((f(Vn)-f(a))/Vn-a)-f(a))/((f(Vn)-f(a))/Vn-a)

    else:
        Vn1=(((f(b)-f(Vn))/b-Vn)-f(Vn))/((f(b)-f(Vn))/b-Vn)
        while abs(Vn1-Vn)<epsilon:
            Vn=Vn1
            Vn1=(((f(b)-f(Vn))/b-Vn)-f(Vn))/((f(b)-f(Vn))/b-Vn)

    return Vn1





























