﻿# Créé par oriviere, le 24/09/2014 en Python 3.2
def fact1(n):     # factorielle avec une boucle
    if n<0 or n!=int(n):
        return 'erreur sur n'
    res=1
    for k in range(1,n+1):
        res*=k    # *= remplace multiplie res par
    return res




def fact2(n):    # factorielle recursive
    if n<0 or n!=int(n):
        return 'erreur sur n'
    if n==0:
        return 1
    else:
        return n*fact2(n-1)



def Sy(n):    #la fonction Syracuse , recursive, mais pour laquelle on ne sait pas prouver qu'on n'a pas une boucle infinie
    if n<1 or int(n) != n:
         return ' n doit être un entier supérieur ou égal à 1'
    else:
        if n==1:
            return 1
        elif n%2==0:
            return Sy(n/2)
        else:
            return Sy(3*n+1)


def pgcd1(a,b):   # le PGCD avec une boucle while . Quel est l'invariant de boucle?
    while b!=0:
        a,b=b,a%b
    return a

def pgcd2(a,b):    # le PGCD récursif. Quel est l'invariant de boucle ?
    if a%b==0:
        return b
    else:
        return pgcd2(b,a%b)



def cbin(n,p):   # calcul des coefficients binomiaux à l'aide du triangle de Pascal
    if p>n or p<0 or n<0 or p!=int(p) or n!= int(n):
        return'il faut donner des entiers positifs,le premier etant superieur ou egal au deuxieme'
    if p==0 or p==n:
        return 1
    else:
        return cbin(n-1,p-1)+cbin(n-1,p)

