﻿# Créé par Cyril, le 30/09/2014 en Python 3.2



def hanoi(n,i,j):
    t1=[]
    t2=[]
    t3=[]
    t=[t1,t2,t3]

    for k in range (n):
        t[i-1].append(k+1)
    t[i-1].reverse()


    if n==1:
        print("Déplacement de l'anneau {} de la tour {} vers la tour {}".format(n,i,j))
        print("A{} : t{} --> t{}\n".format(n,i,j))
        return
    else:
        hanoi(n-1,i,6-(i+j))
        t[j-1].append(t[i-1][len(t[i-1])-1])
        t[i-1].pop
        print("Déplacement de l'anneau {} de la tour {} vers la tour {}".format(n,i,j))
        print("A{} : t{} --> t{}\n".format(n,i,j))
        hanoi(n-1,6-(i+j),j)
        return