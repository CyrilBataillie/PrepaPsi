﻿# Créé par Cyril, le 30/09/2014 en Python 3.2


def suite1(n,a,b,u0,u1): #non récursive
    Un=u0
    Un1=u1
    Un2=0

    if n==0:
        return u0
    if n==1:
        return u1

    for i in range (n-1):
        Un2=a*Un1+b*Un
        Un=Un1
        Un1=Un2

    return Un2


def suite2(n,a,b,u0,u1): #récursive

    if n==0:
        return u0
    elif n==1:
        return u1
    else:
        Un=suite2(n-1,a,b,u0,u1)*a+suite2(n-2,a,b,u0,u1)*b

    return Un





