﻿# Créé par Cyril, le 08/10/2014 en Python 3.2

def listealea():
    import random
    n=int(input('donne la taille de la liste à trier'))
    Ltest=[]
    for j in range(n):
        Ltest.append(random.randint(-5*n,5*n))
    return Ltest


def TriBulle(L):
    for i in range (0,len(L)):
        for k in range (0,len(L)-(i+1)):
            if L[k]>L[k+1]:
                (L[k],L[k+1])=(L[k+1],L[k])
    return L


def triinsertion(L):
    for i in range(1,len(L)):
        x=L[i]
        j=0
        while i-j>0 and L[i-(j+1)]>x :
            L[i-j]=L[i-(j+1)]
            j=j+1
        L[i-j]=x
    return

def quicksort(L):
    n=len(L)
    if L==[] or n==1 :
        return L
    x=L[0]
    Lmin=[]
    Lmax=[]
    for i in range (1,n):
        if L[i]>x:
            Lmax.append(L[i])
        else:
            Lmin.append(L[i])
    return quicksort(Lmin)+[x]+quicksort(Lmax)











def Trirapide(L,deb,fin):
    if deb<fin:
        n=Reorganisation(L,deb,fin)
        Trirapide(L,deb,n-1)
        Trirapide(L,n+1,fin)
    else:
        return L


def Reorganisation(L,deb,fin):
    x=L[deb]
    n=deb
    for i in range(deb+1,fin+1):
        if L[i]<x:
            n=n+1
            L[n],L[i]=L[i],L[n]
        L[deb],L[n]=L[n],L[deb]
        return n





