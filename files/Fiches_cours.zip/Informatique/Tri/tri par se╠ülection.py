﻿# Créé par Cyril, le 01/10/2014 en Python 3.2

def PosMax(p,q,L):
    Pos=p
    for i in range (p,q+1):
        if L[i]>L[Pos]:
            Pos=i
    return Pos


def tri(L):
    for i in range(len(L)):
        P=PosMax(0,len(L)-i-1,L)
        L[P],L[len(L)-i-1]=L[len(L)-i-1],L[P]