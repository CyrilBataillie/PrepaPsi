﻿# Créé par Thomas, le 17/09/2014 en Python 3.2


def creer():
    return[]

def empiler(P,v):
        return(P.append(v))


def depiler(P):
    if vide(P)==0:
        print("La pile est vide")
    else :
        P.remove(P[len(P)-1])
        return(P)

def vide(P):
    if len(P)==0:
        return(0)
    else :
        return(1)

def ecrire(P,v):
    for i in v:
        empiler(P,i)
    return(P)

def BienParenthese(P):
    for i in P:
        if i=='(':
            for j in (i,P):
                if j==')':
                    print(i,j)
                elif j=='(':





