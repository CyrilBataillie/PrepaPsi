﻿# Créé par Thomas, le 02/12/2014 en Python 3.2

class Application(object):
    def __init__(self):
        """Constructeur de la fenêtre principale"""
        self.root=Tk()
        self.root.title('Jeu 421')
        self.dessineDe()
        Button(self.root,text='Lancer',command=self.relancerDe).grid(row=3, sticky=W)
        Label(self.root,text="Couleur Dé 1").grid(row=2)
        self.color1= Entry(self.root, width=14)
        self.color1.grid(row=3)
        Label(self.root,text="Couleur Dé 2").grid(row=4)
        self.color2= Entry(self.root, width=14)
        self.color2.grid(row=5)
        Label(self.root,text="Couleur Dé 3").grid(row=6)
        self.color3= Entry(self.root, width=14)
        self.color3.grid(row=7)
        Button(self.root,text='Redessiner',command=self.changeCouleur(self.color1,self.color2,self.color3)).grid(row=15, sticky=E)
        # Code des couleurs pour les valeurs de zero à neuf:
        self.cc=['black','brown','red','orange','yellow','green','blue','purple','grey','white']


        self.root.mainloop()



    """Dessine le dé"""
    def dessineDe(self):
        """Canevas avec un modele de resistance à trois lignes colorées"""
        self.can=Canvas(self.root,width=250,height=100,bg='light grey')
        self.can.grid(row=1,pady=5,padx=5)
        self.can.create_rectangle(30,30,70,70,fill='white',width=2)
        self.can.create_rectangle(100,30,140,70,fill='white',width=2)
        self.can.create_rectangle(170,30,210,70,fill='white',width=2)

    def changeCouleur(self,color1,color2,color3):
        self.can.create_rectangle(30,30,70,70,fill=str(color1),width=2)
        self.can.create_rectangle(100,30,140,70,fill=str(color2),width=2)
        self.can.create_rectangle(170,30,210,70,fill=str(color3),width=2)


    def relancerDe(self):
            nb=int(input("Combien de dés voulez-vous relancer ?"))
            if nb!=1 and nb!=2 and nb!=3: #on vérifie que l'utilisateur a bien tapé 1,2 ou 3
                print ("Erreur, saisie non valide !")

            for k in range(0,nb):
                choix=input("{} - Lequel voulez-vous relancer, {}, {} ou {} ?".format(k+1,D[1].color,D[2].color,D[3].color))
                if choix!=D[1].color and choix!=D[2].color and choix!=D[3].color: #on vérifie que l'utilisateur a bien tapé une des trois couleurs
                    print ("Erreur, saisie non valide !")
                for i in range (1,4): #on change la valeur du dé voulu
                    if D[i].color==str(choix):
                        D[i].lancerDe()
                    print ()


from tkinter import *
from math import log10
f=Application()
