﻿# Créé par Cyril, le 19/11/2014 en Python 3.2
class CompteBanquaire(object):
    "Traitement de comptes banquaires"

    def __init__(self,name='',num=0,solde=0):
        from random import randint
        self.nom=name
        self.numero=num
        self.solde=solde
        self.__code=randint(0,9999)

    def depot(self,somme):
        self.solde=self.solde+somme

    def retrait(self,somme):
        self.depot(-somme)

    def virement(self,somme,beneficiaire):
        beneficiaire.depot(somme)
        self.retrait(somme)

    def deCode(self):
        return(self.__code)

    def changeCode(self):
        ac=input('Donner votre ancien code')
        print(int(ac))
        if int(ac)==self.deCode():
            self.__code=input('Donner votre nouveau code')
        else:
            return 'Erreur sur le code'


