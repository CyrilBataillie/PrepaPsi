﻿# Créé par Cyril, le 19/11/2014 en Python 3.2
from tkinter import *

class De(object):
    """Création du dé"""
    def __init__(self,color='Blanche'):
        self.color=color
        self.__value=1

    """Lancé de dé"""
    def lancerDe(self):
        from random import randint
        self.__value=randint(1,6)

    """Affiche la valeur du dé en précisant sa couleur"""
    def afficheDe(self):
        return(self.__value,self.color)





def jeu421(color1,color2,color3):
    if color1==color2 or color2==color3 or color1==color3:
        return "Erreur, couleurs identiques !"
    #On crée les 3 dés des couleurs souhaitées
    D=[0,0,0,0]
    D[1]=De(color1)
    D[2]=De(color2)
    D[3]=De(color3)
    for i in range (1,4): #on a 3 essais max
        D[i].lancerDe() #on lance une première fois les 3 dés
    for i in range (1,4): #on affiche la valeur de tous les dés
        print("Dé {}, {}".format(D[i].color,D[i].afficheDe()))

    for i in range (1,3): #on a 3 essais max
        NouvelEssai=input("Voulez-vous relancer les dés ?")
        if NouvelEssai=='oui': #on veut relancer un dé
            nb=int(input("Combien de dés voulez-vous relancer ?"))
            if nb!=1 and nb!=2 and nb!=3: #on vérifie que l'utilisateur a bien tapé 1,2 ou 3
                print ("Erreur, saisie non valide !")

            for k in range(0,nb):
                choix=input("{} - Lequel voulez-vous relancer, {}, {} ou {} ?".format(k+1,D[1].color,D[2].color,D[3].color))
                if choix!=D[1].color and choix!=D[2].color and choix!=D[3].color: #on vérifie que l'utilisateur a bien tapé une des trois couleurs
                    print ("Erreur, saisie non valide !")
                for i in range (1,4): #on change la valeur du dé voulu
                    if D[i].color==str(choix):
                        D[i].lancerDe()
                    print ()
        for i in range (1,4): #on affiche la valeur de tous les dés
            print("Dé {}, {}".format(D[i].color,D[i].afficheDe()))
